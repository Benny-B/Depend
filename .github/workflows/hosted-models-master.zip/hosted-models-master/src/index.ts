/** @ignore */ /** */
// Ignore index from generated docs ^
import { HostedModel, HostedModelConfig } from './HostedModel';

export { HostedModel, HostedModelConfig };
